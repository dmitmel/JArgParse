import github.dmitmel.jargparse.ArgumentParser;
import github.dmitmel.jargparse.Flag;
import github.dmitmel.jargparse.Option;
import github.dmitmel.jargparse.Positional;

public class Example {
    public static void main(String[] args) {
        ArgumentParser parser = new ArgumentParser("my_cool_app",
                "Simple application on Python with command-line argument parser.",
                "1.0");

        parser.addArgument(new Positional("some value",
                "SOME_VALUE"));
        parser.addArgument(new Positional("some optional value",
                "OPTIONAL_VALUE",
                Positional.Usage.OPTIONAL,
                "default value"));
        parser.addArgument(new Positional("values list",
                "VALUES_LIST",
                Positional.Usage.ZERO_OR_MORE));

        parser.addArgument(new Option("-n", "--number",
                "some number",
                "SOME_NUMBER",
                "1"));
        parser.addArgument(new Flag("-V", "--verbose",
                "print what the code does",
                "VERBOSE"));
        parser.addArgument(new Flag(null, "--some-long-flag",
                "some long flag",
                "SOME_LONG_FLAG"));
    }
}
