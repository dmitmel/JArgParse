package com.github.dmitmel.jargparse.util;

public interface Predicate<T> {
    boolean test(T t);
}
